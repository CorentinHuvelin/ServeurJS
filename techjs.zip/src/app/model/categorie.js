class Categorie {
    constructor(object) {
        Object.assign(this,object);
    }
}

module.exports = Categorie;