class Beer {
    constructor(object) {
        Object.assign(this,object);
    }
}

module.exports = Beer;